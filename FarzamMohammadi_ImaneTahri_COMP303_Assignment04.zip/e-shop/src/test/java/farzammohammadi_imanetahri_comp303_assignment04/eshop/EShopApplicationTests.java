package farzammohammadi_imanetahri_comp303_assignment04.eshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EShopApplicationTests {

    @Test
    void contextLoads() {
    }

}
