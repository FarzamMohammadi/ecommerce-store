package com.farzammohammadi_imanetahri_comp303_assignment04.reviewservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
